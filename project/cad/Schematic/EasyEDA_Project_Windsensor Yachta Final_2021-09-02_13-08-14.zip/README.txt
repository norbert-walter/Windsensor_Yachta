<p><strong><span class="VIiyi" lang="en"><span class="JLqJ4b ChMk0b" data-language-for-alternatives="en" data-language-to-translate-into="de" data-phrase-index="0">Wind Sensor Yachta</span></span></strong></p>
<p>&nbsp;</p>
<p><span class="VIiyi" lang="en"><span class="JLqJ4b ChMk0b" data-language-for-alternatives="en" data-language-to-translate-into="de" data-phrase-index="0">The PCB has been developed for the yacht boat wind sensor.</span> <span class="JLqJ4b ChMk0b" data-language-for-alternatives="en" data-language-to-translate-into="de" data-phrase-index="1">The sensors are read out with the board and the data is output via WiFi via the ESP-12E.</span> <span class="JLqJ4b ChMk0b" data-language-for-alternatives="en" data-language-to-translate-into="de" data-phrase-index="2">More details can be found here:</span></span></p>
<p>&nbsp;</p>
<p><a href="https://gitlab.com/norbertwalter67/windsensor_yachta"><span class="VIiyi" lang="en"><span class="JLqJ4b ChMk0b" data-language-for-alternatives="en" data-language-to-translate-into="de" data-phrase-index="2">https://gitlab.com/norbertwalter67/windsensor_yachta</span></span></a></p>
<p><a title="https://open-boat-projects.org/en/universelle-windsensor-firmware/" href="https://open-boat-projects.org/en/universelle-windsensor-firmware/">https://open-boat-projects.org/en/universelle-windsensor-firmware/</a></p>            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。